<?php

namespace phpcron\CronBot\Exception;

/**
 * Main exception class used for exception handling
 */
class CronException extends \Exception
{
    
}
